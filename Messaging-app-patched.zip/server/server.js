import express from "express";
import "dotenv/config";
import cors from "cors";
import http from "http";
import { connectDB } from "./lib/db.js";
import { Server } from "socket.io";
import userRouter from "./routes/userRoutes.js";
import messageRouter from "./routes/messageRoutes.js";

//Create Express app and HTTP server
const app = express();
const server = http.createServer(app);

// simple userSocketMap to track sockets
export const userSocketMap = {};
export const io = new Server(server, {
  cors: { origin: "*" },
});

app.use(express.json({ limit: "4mb" }));
app.use(cors());

// Routes setup
app.use("/api/status", (req, res) => res.send("server is live"));
app.use("/api/auth", userRouter);
app.use("/api/messages", messageRouter);

// Socket.io handlers
io.on("connection", (socket) => {
  console.log("socket connected", socket.id);

  socket.on("registerSocket", (userId) => {
    userSocketMap[userId] = socket.id;
  });

  socket.on("typing", ({from, to})=>{
    const receiverSocketId = userSocketMap[to];
    if(receiverSocketId) io.to(receiverSocketId).emit("typing", {from});
  });

  socket.on("disconnect", () => {
    // remove from map
    for(const [userId,sid] of Object.entries(userSocketMap)){
      if(sid === socket.id) delete userSocketMap[userId];
    }
    console.log("socket disconnected", socket.id);
  });
});

//Connect to MongoDB and start server
const PORT = process.env.PORT || 5000;
async function start(){
  await connectDB();
  server.listen(PORT, () => console.log(`Server running on port: ${PORT}`));
}
start();

export default server;
