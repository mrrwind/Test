import Message from '../models/Message.js';
import User from '../models/User.js';
import { io, userSocketMap } from '../server.js';

// get messages between logged user and another
export const getMessages = async (req,res)=>{
  try{
    const myId = req.user._id;
    const otherId = req.params.userId;
    const messages = await Message.find({
      $or: [{sender: myId, receiver: otherId}, {sender: otherId, receiver: myId}]
    }).sort('createdAt');
    res.json({success:true,messages});
  }catch(e){
    console.error(e);
    res.status(500).json({success:false,message:e.message});
  }
};

export const sendMessage = async (req,res)=>{
  try{
    const sender = req.user._id;
    const {receiver, text, media} = req.body;
    if(!receiver) return res.status(400).json({success:false,message:'No receiver'});
    const newMessage = await Message.create({sender, receiver, text, media});
    // emit to receiver socket if online
    const receiverSocketId = userSocketMap[receiver];
    if(receiverSocketId){
      io.to(receiverSocketId).emit('newMessage', newMessage);
    }
    res.json({success:true,message:newMessage});
  }catch(e){
    console.error(e);
    res.status(500).json({success:false,message:e.message});
  }
};
