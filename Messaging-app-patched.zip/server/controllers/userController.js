import User from '../models/User.js';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

export const registerUser = async (req,res)=>{
  try{
    const {name,email,password} = req.body;
    if(!name||!email||!password) return res.status(400).json({success:false,message:'Missing fields'});
    const exists = await User.findOne({email});
    if(exists) return res.status(400).json({success:false,message:'User exists'});
    const hash = await bcrypt.hash(password,10);
    const user = await User.create({name,email,password:hash});
    const token = jwt.sign({userId:user._id}, process.env.JWT_SECRET||'secret',{expiresIn:'7d'});
    res.json({success:true,user:{_id:user._id,name:user.name,email:user.email,avatar:user.avatar},token});
  }catch(e){
    console.error(e);
    res.status(500).json({success:false,message:e.message});
  }
};

export const loginUser = async (req,res)=>{
  try{
    const {email,password} = req.body;
    const user = await User.findOne({email});
    if(!user) return res.status(400).json({success:false,message:'Invalid credentials'});
    const ok = await bcrypt.compare(password,user.password);
    if(!ok) return res.status(400).json({success:false,message:'Invalid credentials'});
    const token = jwt.sign({userId:user._id}, process.env.JWT_SECRET||'secret',{expiresIn:'7d'});
    res.json({success:true,user:{_id:user._id,name:user.name,email:user.email,avatar:user.avatar},token});
  }catch(e){
    console.error(e);
    res.status(500).json({success:false,message:e.message});
  }
};
