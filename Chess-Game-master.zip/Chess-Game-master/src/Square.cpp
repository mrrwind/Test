#include "Square.h"

Square ::Square()
{
   occupied_color = 0;
   occupied_value = 0;
}
